# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "ADD_ACC_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "BAND0_LIM" -parent ${Page_0}
  ipgui::add_param $IPINST -name "BAND1_LIM" -parent ${Page_0}
  ipgui::add_param $IPINST -name "BAND2_LIM" -parent ${Page_0}
  ipgui::add_param $IPINST -name "BAND3_LIM" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DATA_WIDTH" -parent ${Page_0}


}

proc update_PARAM_VALUE.ADD_ACC_WIDTH { PARAM_VALUE.ADD_ACC_WIDTH } {
	# Procedure called to update ADD_ACC_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ADD_ACC_WIDTH { PARAM_VALUE.ADD_ACC_WIDTH } {
	# Procedure called to validate ADD_ACC_WIDTH
	return true
}

proc update_PARAM_VALUE.BAND0_LIM { PARAM_VALUE.BAND0_LIM } {
	# Procedure called to update BAND0_LIM when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BAND0_LIM { PARAM_VALUE.BAND0_LIM } {
	# Procedure called to validate BAND0_LIM
	return true
}

proc update_PARAM_VALUE.BAND1_LIM { PARAM_VALUE.BAND1_LIM } {
	# Procedure called to update BAND1_LIM when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BAND1_LIM { PARAM_VALUE.BAND1_LIM } {
	# Procedure called to validate BAND1_LIM
	return true
}

proc update_PARAM_VALUE.BAND2_LIM { PARAM_VALUE.BAND2_LIM } {
	# Procedure called to update BAND2_LIM when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BAND2_LIM { PARAM_VALUE.BAND2_LIM } {
	# Procedure called to validate BAND2_LIM
	return true
}

proc update_PARAM_VALUE.BAND3_LIM { PARAM_VALUE.BAND3_LIM } {
	# Procedure called to update BAND3_LIM when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BAND3_LIM { PARAM_VALUE.BAND3_LIM } {
	# Procedure called to validate BAND3_LIM
	return true
}

proc update_PARAM_VALUE.DATA_WIDTH { PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to update DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DATA_WIDTH { PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to validate DATA_WIDTH
	return true
}


proc update_MODELPARAM_VALUE.DATA_WIDTH { MODELPARAM_VALUE.DATA_WIDTH PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DATA_WIDTH}] ${MODELPARAM_VALUE.DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.ADD_ACC_WIDTH { MODELPARAM_VALUE.ADD_ACC_WIDTH PARAM_VALUE.ADD_ACC_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ADD_ACC_WIDTH}] ${MODELPARAM_VALUE.ADD_ACC_WIDTH}
}

proc update_MODELPARAM_VALUE.BAND0_LIM { MODELPARAM_VALUE.BAND0_LIM PARAM_VALUE.BAND0_LIM } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BAND0_LIM}] ${MODELPARAM_VALUE.BAND0_LIM}
}

proc update_MODELPARAM_VALUE.BAND1_LIM { MODELPARAM_VALUE.BAND1_LIM PARAM_VALUE.BAND1_LIM } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BAND1_LIM}] ${MODELPARAM_VALUE.BAND1_LIM}
}

proc update_MODELPARAM_VALUE.BAND2_LIM { MODELPARAM_VALUE.BAND2_LIM PARAM_VALUE.BAND2_LIM } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BAND2_LIM}] ${MODELPARAM_VALUE.BAND2_LIM}
}

proc update_MODELPARAM_VALUE.BAND3_LIM { MODELPARAM_VALUE.BAND3_LIM PARAM_VALUE.BAND3_LIM } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BAND3_LIM}] ${MODELPARAM_VALUE.BAND3_LIM}
}

