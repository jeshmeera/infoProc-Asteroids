# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "FB0_BASE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "FB1_BASE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "FB2_BASE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "HRES" -parent ${Page_0}
  ipgui::add_param $IPINST -name "STRIDE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "VRES" -parent ${Page_0}


}

proc update_PARAM_VALUE.FB0_BASE { PARAM_VALUE.FB0_BASE } {
	# Procedure called to update FB0_BASE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FB0_BASE { PARAM_VALUE.FB0_BASE } {
	# Procedure called to validate FB0_BASE
	return true
}

proc update_PARAM_VALUE.FB1_BASE { PARAM_VALUE.FB1_BASE } {
	# Procedure called to update FB1_BASE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FB1_BASE { PARAM_VALUE.FB1_BASE } {
	# Procedure called to validate FB1_BASE
	return true
}

proc update_PARAM_VALUE.FB2_BASE { PARAM_VALUE.FB2_BASE } {
	# Procedure called to update FB2_BASE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FB2_BASE { PARAM_VALUE.FB2_BASE } {
	# Procedure called to validate FB2_BASE
	return true
}

proc update_PARAM_VALUE.HRES { PARAM_VALUE.HRES } {
	# Procedure called to update HRES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.HRES { PARAM_VALUE.HRES } {
	# Procedure called to validate HRES
	return true
}

proc update_PARAM_VALUE.STRIDE { PARAM_VALUE.STRIDE } {
	# Procedure called to update STRIDE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.STRIDE { PARAM_VALUE.STRIDE } {
	# Procedure called to validate STRIDE
	return true
}

proc update_PARAM_VALUE.VRES { PARAM_VALUE.VRES } {
	# Procedure called to update VRES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.VRES { PARAM_VALUE.VRES } {
	# Procedure called to validate VRES
	return true
}


proc update_MODELPARAM_VALUE.FB0_BASE { MODELPARAM_VALUE.FB0_BASE PARAM_VALUE.FB0_BASE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FB0_BASE}] ${MODELPARAM_VALUE.FB0_BASE}
}

proc update_MODELPARAM_VALUE.FB1_BASE { MODELPARAM_VALUE.FB1_BASE PARAM_VALUE.FB1_BASE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FB1_BASE}] ${MODELPARAM_VALUE.FB1_BASE}
}

proc update_MODELPARAM_VALUE.FB2_BASE { MODELPARAM_VALUE.FB2_BASE PARAM_VALUE.FB2_BASE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FB2_BASE}] ${MODELPARAM_VALUE.FB2_BASE}
}

proc update_MODELPARAM_VALUE.HRES { MODELPARAM_VALUE.HRES PARAM_VALUE.HRES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.HRES}] ${MODELPARAM_VALUE.HRES}
}

proc update_MODELPARAM_VALUE.VRES { MODELPARAM_VALUE.VRES PARAM_VALUE.VRES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.VRES}] ${MODELPARAM_VALUE.VRES}
}

proc update_MODELPARAM_VALUE.STRIDE { MODELPARAM_VALUE.STRIDE PARAM_VALUE.STRIDE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.STRIDE}] ${MODELPARAM_VALUE.STRIDE}
}

