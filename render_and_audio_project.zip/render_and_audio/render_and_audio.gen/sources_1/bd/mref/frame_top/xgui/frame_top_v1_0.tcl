# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "HRES" -parent ${Page_0}
  ipgui::add_param $IPINST -name "INV_AREA_FRAC_BITS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "INV_AREA_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "MAX_TRI_PER_TILE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "NORMAL_FRAC_BITS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "NORMAL_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "NUM_TILES" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCREEN_VERT_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCREEN_XY_FRAC_BITS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCREEN_XY_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCREEN_Z_FRAC_BITS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCREEN_Z_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "TILE_PIXELS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "TILE_SIZE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "TRI_COUNT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "VCOL_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "VRES" -parent ${Page_0}
  ipgui::add_param $IPINST -name "WORLD_FRAC_BITS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "WORLD_W" -parent ${Page_0}


}

proc update_PARAM_VALUE.HRES { PARAM_VALUE.HRES } {
	# Procedure called to update HRES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.HRES { PARAM_VALUE.HRES } {
	# Procedure called to validate HRES
	return true
}

proc update_PARAM_VALUE.INV_AREA_FRAC_BITS { PARAM_VALUE.INV_AREA_FRAC_BITS } {
	# Procedure called to update INV_AREA_FRAC_BITS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.INV_AREA_FRAC_BITS { PARAM_VALUE.INV_AREA_FRAC_BITS } {
	# Procedure called to validate INV_AREA_FRAC_BITS
	return true
}

proc update_PARAM_VALUE.INV_AREA_W { PARAM_VALUE.INV_AREA_W } {
	# Procedure called to update INV_AREA_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.INV_AREA_W { PARAM_VALUE.INV_AREA_W } {
	# Procedure called to validate INV_AREA_W
	return true
}

proc update_PARAM_VALUE.MAX_TRI_PER_TILE { PARAM_VALUE.MAX_TRI_PER_TILE } {
	# Procedure called to update MAX_TRI_PER_TILE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.MAX_TRI_PER_TILE { PARAM_VALUE.MAX_TRI_PER_TILE } {
	# Procedure called to validate MAX_TRI_PER_TILE
	return true
}

proc update_PARAM_VALUE.NORMAL_FRAC_BITS { PARAM_VALUE.NORMAL_FRAC_BITS } {
	# Procedure called to update NORMAL_FRAC_BITS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.NORMAL_FRAC_BITS { PARAM_VALUE.NORMAL_FRAC_BITS } {
	# Procedure called to validate NORMAL_FRAC_BITS
	return true
}

proc update_PARAM_VALUE.NORMAL_W { PARAM_VALUE.NORMAL_W } {
	# Procedure called to update NORMAL_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.NORMAL_W { PARAM_VALUE.NORMAL_W } {
	# Procedure called to validate NORMAL_W
	return true
}

proc update_PARAM_VALUE.NUM_TILES { PARAM_VALUE.NUM_TILES } {
	# Procedure called to update NUM_TILES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.NUM_TILES { PARAM_VALUE.NUM_TILES } {
	# Procedure called to validate NUM_TILES
	return true
}

proc update_PARAM_VALUE.SCREEN_VERT_W { PARAM_VALUE.SCREEN_VERT_W } {
	# Procedure called to update SCREEN_VERT_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCREEN_VERT_W { PARAM_VALUE.SCREEN_VERT_W } {
	# Procedure called to validate SCREEN_VERT_W
	return true
}

proc update_PARAM_VALUE.SCREEN_XY_FRAC_BITS { PARAM_VALUE.SCREEN_XY_FRAC_BITS } {
	# Procedure called to update SCREEN_XY_FRAC_BITS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCREEN_XY_FRAC_BITS { PARAM_VALUE.SCREEN_XY_FRAC_BITS } {
	# Procedure called to validate SCREEN_XY_FRAC_BITS
	return true
}

proc update_PARAM_VALUE.SCREEN_XY_W { PARAM_VALUE.SCREEN_XY_W } {
	# Procedure called to update SCREEN_XY_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCREEN_XY_W { PARAM_VALUE.SCREEN_XY_W } {
	# Procedure called to validate SCREEN_XY_W
	return true
}

proc update_PARAM_VALUE.SCREEN_Z_FRAC_BITS { PARAM_VALUE.SCREEN_Z_FRAC_BITS } {
	# Procedure called to update SCREEN_Z_FRAC_BITS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCREEN_Z_FRAC_BITS { PARAM_VALUE.SCREEN_Z_FRAC_BITS } {
	# Procedure called to validate SCREEN_Z_FRAC_BITS
	return true
}

proc update_PARAM_VALUE.SCREEN_Z_W { PARAM_VALUE.SCREEN_Z_W } {
	# Procedure called to update SCREEN_Z_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCREEN_Z_W { PARAM_VALUE.SCREEN_Z_W } {
	# Procedure called to validate SCREEN_Z_W
	return true
}

proc update_PARAM_VALUE.TILE_PIXELS { PARAM_VALUE.TILE_PIXELS } {
	# Procedure called to update TILE_PIXELS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.TILE_PIXELS { PARAM_VALUE.TILE_PIXELS } {
	# Procedure called to validate TILE_PIXELS
	return true
}

proc update_PARAM_VALUE.TILE_SIZE { PARAM_VALUE.TILE_SIZE } {
	# Procedure called to update TILE_SIZE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.TILE_SIZE { PARAM_VALUE.TILE_SIZE } {
	# Procedure called to validate TILE_SIZE
	return true
}

proc update_PARAM_VALUE.TRI_COUNT { PARAM_VALUE.TRI_COUNT } {
	# Procedure called to update TRI_COUNT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.TRI_COUNT { PARAM_VALUE.TRI_COUNT } {
	# Procedure called to validate TRI_COUNT
	return true
}

proc update_PARAM_VALUE.VCOL_W { PARAM_VALUE.VCOL_W } {
	# Procedure called to update VCOL_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.VCOL_W { PARAM_VALUE.VCOL_W } {
	# Procedure called to validate VCOL_W
	return true
}

proc update_PARAM_VALUE.VRES { PARAM_VALUE.VRES } {
	# Procedure called to update VRES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.VRES { PARAM_VALUE.VRES } {
	# Procedure called to validate VRES
	return true
}

proc update_PARAM_VALUE.WORLD_FRAC_BITS { PARAM_VALUE.WORLD_FRAC_BITS } {
	# Procedure called to update WORLD_FRAC_BITS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.WORLD_FRAC_BITS { PARAM_VALUE.WORLD_FRAC_BITS } {
	# Procedure called to validate WORLD_FRAC_BITS
	return true
}

proc update_PARAM_VALUE.WORLD_W { PARAM_VALUE.WORLD_W } {
	# Procedure called to update WORLD_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.WORLD_W { PARAM_VALUE.WORLD_W } {
	# Procedure called to validate WORLD_W
	return true
}


proc update_MODELPARAM_VALUE.HRES { MODELPARAM_VALUE.HRES PARAM_VALUE.HRES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.HRES}] ${MODELPARAM_VALUE.HRES}
}

proc update_MODELPARAM_VALUE.VRES { MODELPARAM_VALUE.VRES PARAM_VALUE.VRES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.VRES}] ${MODELPARAM_VALUE.VRES}
}

proc update_MODELPARAM_VALUE.TILE_SIZE { MODELPARAM_VALUE.TILE_SIZE PARAM_VALUE.TILE_SIZE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.TILE_SIZE}] ${MODELPARAM_VALUE.TILE_SIZE}
}

proc update_MODELPARAM_VALUE.SCREEN_XY_W { MODELPARAM_VALUE.SCREEN_XY_W PARAM_VALUE.SCREEN_XY_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCREEN_XY_W}] ${MODELPARAM_VALUE.SCREEN_XY_W}
}

proc update_MODELPARAM_VALUE.SCREEN_XY_FRAC_BITS { MODELPARAM_VALUE.SCREEN_XY_FRAC_BITS PARAM_VALUE.SCREEN_XY_FRAC_BITS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCREEN_XY_FRAC_BITS}] ${MODELPARAM_VALUE.SCREEN_XY_FRAC_BITS}
}

proc update_MODELPARAM_VALUE.SCREEN_Z_W { MODELPARAM_VALUE.SCREEN_Z_W PARAM_VALUE.SCREEN_Z_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCREEN_Z_W}] ${MODELPARAM_VALUE.SCREEN_Z_W}
}

proc update_MODELPARAM_VALUE.SCREEN_Z_FRAC_BITS { MODELPARAM_VALUE.SCREEN_Z_FRAC_BITS PARAM_VALUE.SCREEN_Z_FRAC_BITS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCREEN_Z_FRAC_BITS}] ${MODELPARAM_VALUE.SCREEN_Z_FRAC_BITS}
}

proc update_MODELPARAM_VALUE.INV_AREA_W { MODELPARAM_VALUE.INV_AREA_W PARAM_VALUE.INV_AREA_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.INV_AREA_W}] ${MODELPARAM_VALUE.INV_AREA_W}
}

proc update_MODELPARAM_VALUE.INV_AREA_FRAC_BITS { MODELPARAM_VALUE.INV_AREA_FRAC_BITS PARAM_VALUE.INV_AREA_FRAC_BITS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.INV_AREA_FRAC_BITS}] ${MODELPARAM_VALUE.INV_AREA_FRAC_BITS}
}

proc update_MODELPARAM_VALUE.MAX_TRI_PER_TILE { MODELPARAM_VALUE.MAX_TRI_PER_TILE PARAM_VALUE.MAX_TRI_PER_TILE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.MAX_TRI_PER_TILE}] ${MODELPARAM_VALUE.MAX_TRI_PER_TILE}
}

proc update_MODELPARAM_VALUE.WORLD_W { MODELPARAM_VALUE.WORLD_W PARAM_VALUE.WORLD_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.WORLD_W}] ${MODELPARAM_VALUE.WORLD_W}
}

proc update_MODELPARAM_VALUE.WORLD_FRAC_BITS { MODELPARAM_VALUE.WORLD_FRAC_BITS PARAM_VALUE.WORLD_FRAC_BITS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.WORLD_FRAC_BITS}] ${MODELPARAM_VALUE.WORLD_FRAC_BITS}
}

proc update_MODELPARAM_VALUE.NORMAL_W { MODELPARAM_VALUE.NORMAL_W PARAM_VALUE.NORMAL_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.NORMAL_W}] ${MODELPARAM_VALUE.NORMAL_W}
}

proc update_MODELPARAM_VALUE.NORMAL_FRAC_BITS { MODELPARAM_VALUE.NORMAL_FRAC_BITS PARAM_VALUE.NORMAL_FRAC_BITS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.NORMAL_FRAC_BITS}] ${MODELPARAM_VALUE.NORMAL_FRAC_BITS}
}

proc update_MODELPARAM_VALUE.SCREEN_VERT_W { MODELPARAM_VALUE.SCREEN_VERT_W PARAM_VALUE.SCREEN_VERT_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCREEN_VERT_W}] ${MODELPARAM_VALUE.SCREEN_VERT_W}
}

proc update_MODELPARAM_VALUE.NUM_TILES { MODELPARAM_VALUE.NUM_TILES PARAM_VALUE.NUM_TILES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.NUM_TILES}] ${MODELPARAM_VALUE.NUM_TILES}
}

proc update_MODELPARAM_VALUE.TILE_PIXELS { MODELPARAM_VALUE.TILE_PIXELS PARAM_VALUE.TILE_PIXELS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.TILE_PIXELS}] ${MODELPARAM_VALUE.TILE_PIXELS}
}

proc update_MODELPARAM_VALUE.TRI_COUNT { MODELPARAM_VALUE.TRI_COUNT PARAM_VALUE.TRI_COUNT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.TRI_COUNT}] ${MODELPARAM_VALUE.TRI_COUNT}
}

proc update_MODELPARAM_VALUE.VCOL_W { MODELPARAM_VALUE.VCOL_W PARAM_VALUE.VCOL_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.VCOL_W}] ${MODELPARAM_VALUE.VCOL_W}
}

