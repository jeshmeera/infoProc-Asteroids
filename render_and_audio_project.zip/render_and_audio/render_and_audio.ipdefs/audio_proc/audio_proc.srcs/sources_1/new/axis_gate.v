`timescale 1ns / 1ps

module axis_gate #(
    parameter DATA_WIDTH = 32
)(
    input  wire aclk,
    input  wire aresetn,

    input  wire out_en,

    input  wire [DATA_WIDTH-1:0] s_axis_tdata,
    input  wire                  s_axis_tvalid,
    output wire                  s_axis_tready,
    input  wire                  s_axis_tlast,
    input  wire [(DATA_WIDTH/8)-1:0] s_axis_tkeep,

    output reg  [DATA_WIDTH-1:0] m_axis_tdata,
    output reg                   m_axis_tvalid,
    input  wire                  m_axis_tready,
    output reg                   m_axis_tlast,
    output reg  [(DATA_WIDTH/8)-1:0] m_axis_tkeep
);

    reg gate_active;
    reg gate_decision;

    wire handshake = s_axis_tvalid && s_axis_tready;

    assign s_axis_tready =
            gate_decision ? (m_axis_tready || !m_axis_tvalid)
                          : 1'b1;

    always @(posedge aclk) begin
        if (!aresetn) begin
            gate_active    <= 0;
            gate_decision  <= 0;
            m_axis_tvalid  <= 0;
        end else begin
            if (m_axis_tvalid && m_axis_tready)
                m_axis_tvalid <= 0;

            if (handshake) begin

                if (!gate_active) begin
                    gate_active   <= 1'b1;
                    gate_decision <= out_en;
                end

                if (gate_decision) begin
                    m_axis_tdata  <= s_axis_tdata;
                    m_axis_tkeep  <= s_axis_tkeep;
                    m_axis_tlast  <= s_axis_tlast;
                    m_axis_tvalid <= 1'b1;
                end

                if (s_axis_tlast)
                    gate_active <= 1'b0;
            end
        end
    end

endmodule
