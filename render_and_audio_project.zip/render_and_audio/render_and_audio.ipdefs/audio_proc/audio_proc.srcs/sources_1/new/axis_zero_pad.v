`timescale 1ns / 1ps
module axis_zero_pad#
	(
		parameter integer S_DATA_WIDTH	= 24,
		parameter integer M_DATA_WIDTH	= 32
	)
	(
		input wire  aclk,
		input wire  aresetn,
		output wire  s_axis_tready,
		input wire [S_DATA_WIDTH-1 : 0] s_axis_tdata,
		input wire  s_axis_tlast,
		input wire  s_axis_tvalid,

		output wire  m_axis_tvalid,
		output wire [M_DATA_WIDTH-1 : 0] m_axis_tdata,
		output wire  m_axis_tlast,
		input wire  m_axis_tready
	);
    assign m_axis_tvalid = s_axis_tvalid;
    assign m_axis_tdata[M_DATA_WIDTH-1:0] = {{(M_DATA_WIDTH-S_DATA_WIDTH){1'b0}},s_axis_tdata[S_DATA_WIDTH-1:0]};
    assign m_axis_tlast = s_axis_tlast;
    assign m_axis_tvalid = s_axis_tvalid;
    assign s_axis_tready = m_axis_tready;
    
endmodule
