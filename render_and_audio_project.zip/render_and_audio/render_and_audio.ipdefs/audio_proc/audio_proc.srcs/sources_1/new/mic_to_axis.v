`timescale 1ns / 1ps


module mic_to_axis #(
    parameter DATA_WIDTH  = 32,
    parameter PACKET_SIZE = 1024
)(
    input  wire clk,
    input  wire rst,
    input  wire out_en,

    // Input samples
    input  wire pcm_valid_in,
    input  wire signed [DATA_WIDTH-1:0] pcm_data_in,

    // AXI-Stream output
    output reg  [DATA_WIDTH-1:0] m_axis_tdata,
    output reg                   m_axis_tvalid,
    input  wire                  m_axis_tready,
    output wire                   m_axis_tlast,
    output wire [(DATA_WIDTH/8)-1:0] m_axis_tkeep,
    
    output reg [DATA_WIDTH-1:0] sent_c
);

    reg [7:0] count;

    reg [$clog2(PACKET_SIZE):0] packet_count;

    reg signed [DATA_WIDTH-1:0] next_data;
    reg  sample_ready;

    assign m_axis_tkeep = {(DATA_WIDTH/8){1'b1}};
    assign m_axis_tlast = m_axis_tvalid  && (packet_count == PACKET_SIZE-1);
    always @(posedge clk) begin
        if (rst) begin
            count          <= 0;
            m_axis_tvalid  <= 0;
            m_axis_tdata   <= 0;
            packet_count   <= 0;
            sample_ready   <= 0;
          
            sent_c<=0;
        end else begin
            //m_axis_tlast <= 0;

            if (pcm_valid_in) begin
                count <= count + 1;
                sample_ready <= 1;
                next_data <= pcm_data_in;
            end


            if (sample_ready) begin
                if (!m_axis_tvalid || m_axis_tready) begin
                    m_axis_tdata  <= next_data;
                    m_axis_tvalid <= out_en;
                    sample_ready <= 0;
                end
                count        <= 0;
            end


            if (m_axis_tvalid && m_axis_tready) begin
                m_axis_tvalid <= 0;
                sent_c <= sent_c+1;  
                if (m_axis_tlast) begin
                    packet_count <= 0;
                end else begin
                    packet_count <= packet_count + 1;
                end
            end
            
        end
    end

endmodule

