// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcol.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCol_CfgInitialize(XCol *InstancePtr, XCol_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCol_Start(XCol *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCol_IsDone(XCol *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCol_IsIdle(XCol *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCol_IsReady(XCol *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCol_EnableAutoRestart(XCol *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XCol_DisableAutoRestart(XCol *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_AP_CTRL, 0);
}

void XCol_Set_N(XCol *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_N_DATA, Data);
}

u32 XCol_Get_N(XCol *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_N_DATA);
    return Data;
}

void XCol_Set_frame_dt(XCol *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_FRAME_DT_DATA, Data);
}

u32 XCol_Get_frame_dt(XCol *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_FRAME_DT_DATA);
    return Data;
}

void XCol_Set_restitution(XCol *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_RESTITUTION_DATA, Data);
}

u32 XCol_Get_restitution(XCol *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_RESTITUTION_DATA);
    return Data;
}

void XCol_Set_state_in(XCol *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_r_BaseAddress, XCOL_CONTROL_R_ADDR_STATE_IN_DATA, (u32)(Data));
    XCol_WriteReg(InstancePtr->Control_r_BaseAddress, XCOL_CONTROL_R_ADDR_STATE_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XCol_Get_state_in(XCol *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_r_BaseAddress, XCOL_CONTROL_R_ADDR_STATE_IN_DATA);
    Data += (u64)XCol_ReadReg(InstancePtr->Control_r_BaseAddress, XCOL_CONTROL_R_ADDR_STATE_IN_DATA + 4) << 32;
    return Data;
}

void XCol_Set_state_out(XCol *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_r_BaseAddress, XCOL_CONTROL_R_ADDR_STATE_OUT_DATA, (u32)(Data));
    XCol_WriteReg(InstancePtr->Control_r_BaseAddress, XCOL_CONTROL_R_ADDR_STATE_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XCol_Get_state_out(XCol *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCol_ReadReg(InstancePtr->Control_r_BaseAddress, XCOL_CONTROL_R_ADDR_STATE_OUT_DATA);
    Data += (u64)XCol_ReadReg(InstancePtr->Control_r_BaseAddress, XCOL_CONTROL_R_ADDR_STATE_OUT_DATA + 4) << 32;
    return Data;
}

void XCol_InterruptGlobalEnable(XCol *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_GIE, 1);
}

void XCol_InterruptGlobalDisable(XCol *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_GIE, 0);
}

void XCol_InterruptEnable(XCol *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_IER);
    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_IER, Register | Mask);
}

void XCol_InterruptDisable(XCol *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_IER);
    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XCol_InterruptClear(XCol *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCol_WriteReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_ISR, Mask);
}

u32 XCol_InterruptGetEnabled(XCol *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_IER);
}

u32 XCol_InterruptGetStatus(XCol *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCol_ReadReg(InstancePtr->Control_BaseAddress, XCOL_CONTROL_ADDR_ISR);
}

