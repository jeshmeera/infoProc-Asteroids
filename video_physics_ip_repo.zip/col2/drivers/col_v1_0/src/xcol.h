// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XCOL_H
#define XCOL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcol_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
    u32 Control_r_BaseAddress;
} XCol_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XCol;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCol_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCol_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCol_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCol_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XCol_Initialize(XCol *InstancePtr, u16 DeviceId);
XCol_Config* XCol_LookupConfig(u16 DeviceId);
int XCol_CfgInitialize(XCol *InstancePtr, XCol_Config *ConfigPtr);
#else
int XCol_Initialize(XCol *InstancePtr, const char* InstanceName);
int XCol_Release(XCol *InstancePtr);
#endif

void XCol_Start(XCol *InstancePtr);
u32 XCol_IsDone(XCol *InstancePtr);
u32 XCol_IsIdle(XCol *InstancePtr);
u32 XCol_IsReady(XCol *InstancePtr);
void XCol_EnableAutoRestart(XCol *InstancePtr);
void XCol_DisableAutoRestart(XCol *InstancePtr);

void XCol_Set_N(XCol *InstancePtr, u32 Data);
u32 XCol_Get_N(XCol *InstancePtr);
void XCol_Set_frame_dt(XCol *InstancePtr, u32 Data);
u32 XCol_Get_frame_dt(XCol *InstancePtr);
void XCol_Set_restitution(XCol *InstancePtr, u32 Data);
u32 XCol_Get_restitution(XCol *InstancePtr);
void XCol_Set_state_in(XCol *InstancePtr, u64 Data);
u64 XCol_Get_state_in(XCol *InstancePtr);
void XCol_Set_state_out(XCol *InstancePtr, u64 Data);
u64 XCol_Get_state_out(XCol *InstancePtr);

void XCol_InterruptGlobalEnable(XCol *InstancePtr);
void XCol_InterruptGlobalDisable(XCol *InstancePtr);
void XCol_InterruptEnable(XCol *InstancePtr, u32 Mask);
void XCol_InterruptDisable(XCol *InstancePtr, u32 Mask);
void XCol_InterruptClear(XCol *InstancePtr, u32 Mask);
u32 XCol_InterruptGetEnabled(XCol *InstancePtr);
u32 XCol_InterruptGetStatus(XCol *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
