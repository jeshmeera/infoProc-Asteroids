// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - enable ap_done interrupt (Read/Write)
//        bit 1  - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - ap_done (COR/TOW)
//        bit 1  - ap_ready (COR/TOW)
//        others - reserved
// 0x10 : Data signal of N
//        bit 31~0 - N[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of frame_dt
//        bit 31~0 - frame_dt[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of restitution
//        bit 31~0 - restitution[31:0] (Read/Write)
// 0x24 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCOL_CONTROL_ADDR_AP_CTRL          0x00
#define XCOL_CONTROL_ADDR_GIE              0x04
#define XCOL_CONTROL_ADDR_IER              0x08
#define XCOL_CONTROL_ADDR_ISR              0x0c
#define XCOL_CONTROL_ADDR_N_DATA           0x10
#define XCOL_CONTROL_BITS_N_DATA           32
#define XCOL_CONTROL_ADDR_FRAME_DT_DATA    0x18
#define XCOL_CONTROL_BITS_FRAME_DT_DATA    32
#define XCOL_CONTROL_ADDR_RESTITUTION_DATA 0x20
#define XCOL_CONTROL_BITS_RESTITUTION_DATA 32

// control_r
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of state_in
//        bit 31~0 - state_in[31:0] (Read/Write)
// 0x14 : Data signal of state_in
//        bit 31~0 - state_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of state_out
//        bit 31~0 - state_out[31:0] (Read/Write)
// 0x20 : Data signal of state_out
//        bit 31~0 - state_out[63:32] (Read/Write)
// 0x24 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCOL_CONTROL_R_ADDR_STATE_IN_DATA  0x10
#define XCOL_CONTROL_R_BITS_STATE_IN_DATA  64
#define XCOL_CONTROL_R_ADDR_STATE_OUT_DATA 0x1c
#define XCOL_CONTROL_R_BITS_STATE_OUT_DATA 64

