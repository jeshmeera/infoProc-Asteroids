// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xcol.h"

extern XCol_Config XCol_ConfigTable[];

XCol_Config *XCol_LookupConfig(u16 DeviceId) {
	XCol_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCOL_NUM_INSTANCES; Index++) {
		if (XCol_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XCol_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCol_Initialize(XCol *InstancePtr, u16 DeviceId) {
	XCol_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCol_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCol_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

